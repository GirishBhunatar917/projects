create database ecommerce;

use ecommerce;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE,
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255)
);

select * from users;

CREATE TABLE categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL
);

CREATE TABLE products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    description TEXT,
    image blob,
    category_id INT,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);



select * from products;
select * from categories;

truncate table categories;
delete from categories where id=3;
delete from products where id=9;
truncate table products;

select * from products;

drop table products;

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    total_amount DOUBLE NOT NULL,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status VARCHAR(20) DEFAULT 'Pending',  -- Status can be 'Pending', 'Shipped', 'Cancelled'
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

select * from orders;
drop table orders;
ALTER TABLE users ADD COLUMN status ENUM('active', 'inactive') DEFAULT 'active';


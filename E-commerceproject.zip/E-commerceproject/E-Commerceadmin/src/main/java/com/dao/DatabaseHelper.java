package com.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.pojo.user;

public class DatabaseHelper {

    private static final String JDBC_URL = "jdbc:mysql://localhost/ecommerce";
    private static final String JDBC_USERNAME = "root";
    private static final String JDBC_PASSWORD = "";

    // Method to fetch user data
    public List<user> getUsers() {
        List<user> users = new ArrayList<>();
        String query = "SELECT id, username, email, password, status FROM users";

        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
                 PreparedStatement stmt = conn.prepareStatement(query);
                 ResultSet rs = stmt.executeQuery()) {

                // Loop through the results and populate the list
                while (rs.next()) {
                    int id = rs.getInt("id");
                    String username = rs.getString("username");
                    String email = rs.getString("email");
                    String password = rs.getString("password");
                    String status = rs.getString("status");

                    users.add(new user(id, username, email, password, status));
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return users;
    }

    // Method to update the user's status
    public void updateUserStatus(int id, String status) {
        // Only valid ENUM values should be passed
        if (!status.equals("active") && !status.equals("inactive")) {
            throw new IllegalArgumentException("Invalid status: " + status);
        }

        String query = "UPDATE users SET status = ? WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1,status); // set the status
            stmt.setInt(2,id); // set the user ID
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

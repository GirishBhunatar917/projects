package com.admin;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

@MultipartConfig
@WebServlet("/addProduct")
public class AddProductServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Load the MySQL driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            request.setAttribute("error", "MySQL Driver not found.");
            request.getRequestDispatcher("/adminAddProduct.jsp").forward(request, response);
            return;
        }

        String name = request.getParameter("name");
        double price = Double.parseDouble(request.getParameter("price"));
        String description = request.getParameter("description");
        int categoryId = Integer.parseInt(request.getParameter("category_id"));

        Part filePart = request.getPart("image");
        
        // Read the image content into a byte array
        byte[] imageBytes = null;
        try (InputStream fileContent = filePart.getInputStream();
             ByteArrayOutputStream buffer = new ByteArrayOutputStream()) {
             
            byte[] temp = new byte[1024];
            int bytesRead;
            while ((bytesRead = fileContent.read(temp)) != -1) {
                buffer.write(temp, 0, bytesRead);
            }
            imageBytes = buffer.toByteArray();
        }

        String query = "INSERT INTO products (name, price, description, image, category_id) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/ecommerce", "root", "");
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, name);
            stmt.setDouble(2, price);
            stmt.setString(3, description);
            stmt.setBytes(4, imageBytes); // Store the byte array directly
            stmt.setInt(5, categoryId);

            int status = stmt.executeUpdate();
            if (status > 0) {
                request.setAttribute("success", true);
            } else {
                request.setAttribute("error", "Product not added. Please try again.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("error", "Database error: " + e.getMessage());
        }

        // Forward back to the JSP with the success or error message
        request.getRequestDispatcher("/adminAddProduct.jsp").forward(request, response);
    }
}

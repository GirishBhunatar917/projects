package com.admin;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/addCategory")
public class AddCategoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String categoryName = request.getParameter("name");

        String query = "INSERT INTO categories (name) VALUES (?)";

        try {
            // Load the MySQL driver (if required by your setup)
            Class.forName("com.mysql.cj.jdbc.Driver");

            try (Connection conn = DriverManager.getConnection(
                     "jdbc:mysql://localhost:/ecommerce", "root", "");
                 PreparedStatement stmt = conn.prepareStatement(query)) {

                stmt.setString(1, categoryName);
                stmt.executeUpdate();
                response.sendRedirect("adminAddCategory.jsp?success=true");

            } catch (SQLException e) {
                e.printStackTrace();
                response.sendRedirect("adminAddCategory.jsp?error=Database error: " + e.getMessage());
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("adminAddCategory.jsp?error=Driver not found: " + e.getMessage());
        }
    }
}

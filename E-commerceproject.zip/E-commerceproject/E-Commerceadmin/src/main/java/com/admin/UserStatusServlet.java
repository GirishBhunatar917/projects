package com.admin;

import com.dao.DatabaseHelper;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/UserStatusServlet")
public class UserStatusServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idStr = request.getParameter("id");
        String action = request.getParameter("action");

        // Validate and parse the id
        if (idStr != null && !idStr.isEmpty()) {
            try {
                int userId = Integer.parseInt(idStr);
                DatabaseHelper dbHelper = new DatabaseHelper();

                if ("deactivate".equals(action)) {
                    dbHelper.updateUserStatus(userId, "inactive");
                } else if ("activate".equals(action)) {
                    dbHelper.updateUserStatus(userId, "active");
                }
                response.sendRedirect("manageUsers.jsp"); // Redirect back to the Manage Users page

            } catch (NumberFormatException e) {
                e.printStackTrace(); // Handle the exception, maybe log it
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid user ID.");
            }
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "User ID is missing or invalid.");
        }
    }
}

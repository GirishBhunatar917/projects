package com.controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;

import com.dao.DAO;

@WebServlet("/ImageServlet")
public class ImageServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id")); // Get the product ID from the request
        byte[] image = DAO.getImageById(id); // Fetch the image byte array from DAO

        response.setContentType("image/*"); // Set content type based on the image type
        try (OutputStream out = response.getOutputStream()) {
            if (image != null) {
                out.write(image); // Write the image byte array to the output stream
            }
        }
    }
}

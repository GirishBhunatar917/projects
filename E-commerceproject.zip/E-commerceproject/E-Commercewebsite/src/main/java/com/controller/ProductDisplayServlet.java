package com.controller;

import java.io.IOException;
import java.util.Base64;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DAO;
import com.pojo.Product;

@WebServlet("/ProductDisplayServlet")
public class ProductDisplayServlet extends HttpServlet {

 
	private static final long serialVersionUID = 1L;

	@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("getImage".equals(action)) {
            int id = Integer.parseInt(request.getParameter("id"));
            byte[] image = DAO.getImageById(id); 

            response.setContentType("image/*"); 
            response.setContentLength(image.length);
            response.getOutputStream().write(image); 
        } else {
          
            List<Product> products = DAO.getalldata();

            
            for (Product product : products) {
                byte[] imageBytes = product.getImage();
                if (imageBytes != null) {
                    String base64Image = Base64.getEncoder().encodeToString(imageBytes);
                    product.setBase64Image(base64Image);
                   
       
                 
                }
            }

            request.setAttribute("products", products);

            // Forward to the JSP page for rendering
            RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp"); 
            dispatcher.forward(request, response);
        }
    }
}

package com.controller;

import com.dao.DAO;
import com.pojo.User;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
 
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Validate user credentials and check status
        User user = DAO.validateUser(username, password);

        if (user != null) {
            // User is valid and active
            HttpSession session = request.getSession();
            session.setAttribute("id", user.getId());
            session.setAttribute("username", user.getUsername());  // Optionally store username
            response.sendRedirect("index.jsp");  // Redirect to the home page after login
        } else {
            // Invalid credentials or inactive user
            response.sendRedirect("login.jsp?error=Invalid credentials or inactive account");
        }
    }
}

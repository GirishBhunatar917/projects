package com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.DAO;
import com.pojo.CartItem;
import com.pojo.Order;

@WebServlet("/OrderManagementServlet")  // URL to handle both viewing and creating orders
 
public class OrderManagementServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Handle GET requests (view orders)
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();

        // Get userId from session
        Integer userId = (Integer) session.getAttribute("id");

        if (userId == null) {
            // If the user is not logged in, redirect to login page
            response.sendRedirect("login.jsp");
            return;
        }

        // Retrieve the list of orders for the user from the DAO
        List<Order> orders = DAO.getOrdersByUserId(userId);

        // Debug: Print orders size and details to the console (for server-side logs)
        System.out.println("Orders for userId " + userId + ": " + (orders != null ? orders.size() : 0));

        if (orders != null && !orders.isEmpty()) {
            for (Order order : orders) {
                System.out.println("Order ID: " + order.getId() + ", Product: " + order.getProductName() + ", Quantity: " + order.getQuantity());
            }
        } else {
            System.out.println("No orders found for userId: " + userId);
        }

        // Set the list of orders as a request attribute
        request.setAttribute("orders", orders);

        // Forward the request to the Orders.jsp page to display orders
        RequestDispatcher dispatcher = request.getRequestDispatcher("Orders.jsp");
        dispatcher.forward(request, response);
    }

    // Handle POST requests (create order from cart items)
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("Order request received");

        // Get the session and user ID
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("id");

        if (userId == null) {
            // If the user is not logged in, redirect to login page
            response.sendRedirect("login.jsp");
            return;
        }

        // Retrieve cart items from session
        @SuppressWarnings("unchecked")
        List<CartItem> cartItems = (List<CartItem>) session.getAttribute("cartItems");

        if (cartItems == null || cartItems.isEmpty()) {
            // If cart is empty, redirect to cart page
            response.sendRedirect("cart.jsp");
            return;
        }

        // Process each cart item to create an order
        for (CartItem cartItem : cartItems) {
            Order order = new Order();
            order.setUserId(userId);
            order.setProductId(cartItem.getProduct().getId());
            order.setQuantity(cartItem.getQuantity());
            order.setTotalAmount(cartItem.getProduct().getPrice() * cartItem.getQuantity());

            // Set product name from product object in cartItem
            order.setProductName(cartItem.getProduct().getName());

            // Assuming DAO.createOrder returns a boolean indicating success
            boolean isOrderCreated = DAO.createOrder(order);

            if (!isOrderCreated) {
                // If order creation failed, redirect to error page
                response.sendRedirect("errorPage.jsp");
                return;
            }
        }

        // After order creation, clear the cart
        session.removeAttribute("cartItems");

        // Redirect to the OrdersServlet to view the newly created orders
        response.sendRedirect("OrderManagementServlet");  // No action needed here, just redirects to the GET method
    }
}

package com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DAO;
import com.pojo.Product;

/**
 * Servlet implementation class s
 */
@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the search query from the request
        String query = request.getParameter("query");
        
        if (query == null || query.isEmpty()) {
            response.sendRedirect("index.jsp?message=Please enter a search term.");
            return;
        }
        
        // Perform the database search
        DAO productDAO = new DAO(); // Assuming you have a ProductDAO class to handle DB operations
        List<Product> searchResults = productDAO.searchProducts(query);

        // Set the search results as a request attribute to display on the search results page
        request.setAttribute("searchResults", searchResults);

        // Forward to the search results page
        RequestDispatcher dispatcher = request.getRequestDispatcher("SearchResult.jsp");
        dispatcher.forward(request, response);
    }
}

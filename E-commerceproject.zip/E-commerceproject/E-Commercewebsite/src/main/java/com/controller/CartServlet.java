package com.controller;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.dao.DAO;
import com.pojo.CartItem;
import com.pojo.Product;
import java.io.*;
import java.util.*;

@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();

        // Get cart items from session, if not present initialize a new cart
        @SuppressWarnings("unchecked")
        List<CartItem> cartItems = (List<CartItem>) session.getAttribute("cartItems");
        if (cartItems == null) {
            cartItems = new ArrayList<>();
            session.setAttribute("cartItems", cartItems);
        }

        // Get product ID and quantity from the request
        int productId = Integer.parseInt(request.getParameter("id"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        // Get product details from the database
        Product product = DAO.getProductById(productId);

        if (product == null) {
            // If product not found, send a redirect to error page (optional)
            response.sendRedirect("errorPage.jsp");
            return;
        }

        // Check if the product is already in the cart
        boolean productFound = false;
        for (CartItem item : cartItems) {
            if (item.getProduct().getId() == productId) {
                item.setQuantity(item.getQuantity() + quantity); // Update quantity
                productFound = true;
                break;
            }
        }

        // If product is not in the cart, add it
        if (!productFound) {
            CartItem cartItem = new CartItem(product, quantity);
            cartItems.add(cartItem);
        }

        // Recalculate the total amount
        double totalAmount = 0;
        for (CartItem item : cartItems) {
            totalAmount += item.getProduct().getPrice() * item.getQuantity();
        }

        // Set the updated cart items and total amount in the session
        session.setAttribute("cartItems", cartItems);
        session.setAttribute("totalAmount", totalAmount);

        // Forward to the Cart.jsp page
        request.setAttribute("cartItems", cartItems);
        request.setAttribute("totalAmount", totalAmount);
        request.getRequestDispatcher("Cart.jsp").forward(request, response);
    }

    // Handle GET request (optional, in case the same logic is needed for GET)
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();

        // Get cart items from session
        @SuppressWarnings("unchecked")
        List<CartItem> cartItems = (List<CartItem>) session.getAttribute("cartItems");

        // Handle removal of an item from the cart
        String removeId = request.getParameter("removeId");
        if (removeId != null) {
            int productIdToRemove = Integer.parseInt(removeId);

            // Remove the product from the cart
            cartItems.removeIf(item -> item.getProduct().getId() == productIdToRemove);

            // Recalculate the total amount after removal
            double totalAmount = 0;
            for (CartItem item : cartItems) {
                totalAmount += item.getProduct().getPrice() * item.getQuantity();
            }

            // Update session after removal
            session.setAttribute("cartItems", cartItems);
            session.setAttribute("totalAmount", totalAmount);
        }

        // Forward to Cart.jsp with updated cart
        request.setAttribute("cartItems", cartItems);
        request.setAttribute("totalAmount", session.getAttribute("totalAmount"));
        request.getRequestDispatcher("Cart.jsp").forward(request, response);
    }
}

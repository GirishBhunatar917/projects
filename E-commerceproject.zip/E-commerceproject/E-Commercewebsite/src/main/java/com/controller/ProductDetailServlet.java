package com.controller;

import java.io.IOException;
import java.util.Base64;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DAO;
import com.pojo.Product;

@WebServlet("/ProductDetailServlet")
public class ProductDetailServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	int productId = Integer.parseInt(request.getParameter("id"));

  
    	Product product = DAO.getProductById(productId);

   
    	if (product != null && product.getImage() != null) {
    	
    	    byte[] imageBytes = product.getImage();
    	    String base64Image = Base64.getEncoder().encodeToString(imageBytes);
    	    product.setBase64Image(base64Image);  
    	}

    	
    	request.setAttribute("product", product); 
        

        
        RequestDispatcher dispatcher = request.getRequestDispatcher("ProductDetail.jsp");
        dispatcher.forward(request, response);
    }
}

package com.controller;

import com.dao.DAO;
import com.pojo.Category;
import com.pojo.Product;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/CategoryServlet")
public class CategoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // This method handles GET requests
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String categoryName = request.getParameter("category");  // Get the category from the URL parameter
        List<Product> products = new ArrayList<>();
        List<Category> categories = new ArrayList<>();

        // Fetch all categories to display on the sidebar
        String categoryQuery = "SELECT id, name FROM categories";
        try (Connection conn = DAO.myConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(categoryQuery)) {

            while (rs.next()) {
                Category category = new Category();
                category.setId(rs.getInt("id"));
                category.setName(rs.getString("name"));
                categories.add(category);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Fetch products based on the specified category
        if (categoryName != null && !categoryName.isEmpty()) {
            String sql = "SELECT p.id, p.name, p.price, p.description, p.category_id, p.image " +
                         "FROM products p JOIN categories c ON p.category_id = c.id WHERE c.name = ?";
            try (Connection conn = DAO.myConnection();
                 PreparedStatement stmt = conn.prepareStatement(sql)) {

                stmt.setString(1, categoryName);  // Set the category name in the query
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    Product product = new Product();
                    product.setId(rs.getInt("id"));
                    product.setName(rs.getString("name"));
                    product.setPrice(rs.getDouble("price"));
                    product.setDescription(rs.getString("description"));
                    product.setCategoryId(rs.getInt("category_id"));
                    product.setCategoryName(categoryName);  // Set category name in product
                    product.setImage(rs.getBytes("image"));

                    // Convert image to base64 if image is present
                    if (product.getImage() != null) {
                        String base64Image = java.util.Base64.getEncoder().encodeToString(product.getImage());
                        product.setBase64Image(base64Image);
                    }

                    products.add(product);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        // Set products and categories as request attributes for the JSP
        request.setAttribute("products", products);
        request.setAttribute("category", categoryName);
        request.setAttribute("categories", categories);

        // Forward the request to the JSP
        RequestDispatcher dispatcher = request.getRequestDispatcher("category.jsp");
        dispatcher.forward(request, response);
    }
}

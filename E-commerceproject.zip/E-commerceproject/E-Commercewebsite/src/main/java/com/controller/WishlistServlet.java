package com.controller;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import com.dao.DAO;
import com.pojo.CartItem;
import com.pojo.Product;
import java.io.*;
import java.util.*;

@WebServlet("/WishlistServlet")
public class WishlistServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Handle POST request for adding products to the wishlist
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();

        // Retrieve wishlist items from session or initialize a new list if not present
        @SuppressWarnings("unchecked")
        List<Product> wishlistItems = (List<Product>) session.getAttribute("wishlistItems");
        if (wishlistItems == null) {
            wishlistItems = new ArrayList<>();
            session.setAttribute("wishlistItems", wishlistItems);
        }

        // Get product ID from request
        int productId = Integer.parseInt(request.getParameter("id"));

        // Fetch product details from database
        Product product = DAO.getProductById(productId);
        if (product != null) {
            // Check if product already exists in wishlist
            boolean productFound = false;
            for (Product item : wishlistItems) {
                if (item.getId() == productId) {
                    productFound = true;
                    break;
                }
            }

            // If not in wishlist, add to the list
            if (!productFound) {
                wishlistItems.add(product);
            }
        }

        // Forward to the wishlist page
        request.getRequestDispatcher("wishlist.jsp").forward(request, response);
    }

    // Handle GET request for removing items from the wishlist or adding them to the cart
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        @SuppressWarnings("unchecked")
        List<Product> wishlistItems = (List<Product>) session.getAttribute("wishlistItems");
        @SuppressWarnings("unchecked")
        List<CartItem> cartItems = (List<CartItem>) session.getAttribute("cartItems");

        if (wishlistItems != null) {
            String removeId = request.getParameter("removeId");
            if (removeId != null) {
                // Remove product from wishlist
                wishlistItems.removeIf(item -> item.getId() == Integer.parseInt(removeId));
                session.setAttribute("wishlistItems", wishlistItems); // Update wishlist items in session
            }

            String addToCartId = request.getParameter("addToCartId");
            if (addToCartId != null) {
                // Get the quantity from the request (default to 1 if not provided)
                int quantity = 1;
                String quantityStr = request.getParameter("quantity");
                if (quantityStr != null && !quantityStr.isEmpty()) {
                    quantity = Integer.parseInt(quantityStr);
                }

                // Get the product from wishlist and add it to the cart
                Product productToAdd = null;
                for (Product item : wishlistItems) {
                    if (item.getId() == Integer.parseInt(addToCartId)) {
                        productToAdd = item;
                        break;
                    }
                }

                if (productToAdd != null) {
                    // Add product to the cart with the specified quantity
                    if (cartItems == null) {
                        cartItems = new ArrayList<>();
                        session.setAttribute("cartItems", cartItems);
                    }
                    cartItems.add(new CartItem(productToAdd, quantity)); // Add with the specified quantity

                    // Remove product from wishlist
                    wishlistItems.removeIf(item -> item.getId() == Integer.parseInt(addToCartId));
                    session.setAttribute("wishlistItems", wishlistItems); // Update wishlist items in session
                }
            }
        }

        // Forward to wishlist.jsp with updated wishlist
        request.getRequestDispatcher("wishlist.jsp").forward(request, response);
    }
}

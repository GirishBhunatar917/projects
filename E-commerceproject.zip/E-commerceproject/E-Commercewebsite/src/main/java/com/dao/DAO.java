package com.dao;

import com.pojo.Order;
import com.pojo.Product;
import com.pojo.User;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

public class DAO {

    public static Connection myConnection() {
        Connection cn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); 
            cn = DriverManager.getConnection("jdbc:mysql://localhost/ecommerce", "root", "");
        } catch (SQLException e) {
            System.out.println("SQL Exception: " + e.getMessage());
        } catch (ClassNotFoundException e) {
            System.out.println("JDBC Driver not found: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Connection error: " + e.getMessage());
        }
        return cn;
    }

    public static int registerUser(User user) {
        int status = 0;
        Connection cn = myConnection();

        String insert = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
        
        try (PreparedStatement ps = cn.prepareStatement(insert)) {
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPassword());
            status = ps.executeUpdate();
            
            if (status > 0) {
                System.out.println("User registered successfully");
            }
        } catch (SQLException e) {
            System.out.println("User registration failed: " + e.getMessage());
        }
        
        return status;
    }

    public static User validateUser(String username, String password) {
        User user = null;
        Connection cn = myConnection();

        String fetch = "SELECT * FROM users WHERE username = ? AND password = ? AND status = 'active'";
        
        try (PreparedStatement ps = cn.prepareStatement(fetch)) {
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet r = ps.executeQuery();
            
            if (r.next()) {
                user = new User();
                user.setId(r.getInt("id"));
                user.setUsername(r.getString("username"));
                user.setPassword(r.getString("password"));
                user.setStatus(r.getString("status")); 
            }
        } catch (SQLException e) {
            System.out.println("User validation failed: " + e.getMessage());
        }
        
        return user;
    }

    
    public static List<Product> getalldata() {
        List<Product> products = new ArrayList<>();
        Connection cn = myConnection();

        String query = "SELECT id, name, price,image FROM products"; 

        try (PreparedStatement ps = cn.prepareStatement(query); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt("id"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getDouble("price"));
                product.setImage(rs.getBytes("image"));
          

                products.add(product);
            }
        } catch (SQLException e) {
            System.out.println("Failed to fetch products: " + e.getMessage());
        }

        return products;
    }

    public static byte[] getImageById(int id) {
        byte[] image = null;
        Connection cn = myConnection();
        
        String query = "SELECT image FROM products WHERE id = ?";
        
        try (PreparedStatement ps = cn.prepareStatement(query)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                image = rs.getBytes("image"); // Get the image as byte array
            }
        } catch (SQLException e) {
            System.out.println("Failed to fetch image: " + e.getMessage());
        }
        
        return image;
    }

    public  static Product getProductById(int id) {
        Product product = null;

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce", "root", "");
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM products WHERE id = ?")) {
            
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            
            if (resultSet.next()) {
                product = new Product();
                product.setId(resultSet.getInt("id"));
                product.setName(resultSet.getString("name"));
                product.setPrice(resultSet.getDouble("price"));
                product.setDescription(resultSet.getString("description"));
                
                // Assuming the image is stored as a BLOB in the database
                byte[] image = resultSet.getBytes("image");
                
                if (image != null) {
                    // Convert byte array to Base64 string
                    String base64Image = convertImageToBase64(image);
                    product.setBase64Image(base64Image);  // Set Base64 image in product
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return product;
    }

    // Convert byte array to Base64 string
    public static String convertImageToBase64(byte[] imageBytes) {
        return Base64.getEncoder().encodeToString(imageBytes);
    }
    public List<Product> searchProducts(String query) {
        List<Product> products = new ArrayList<>();
        String sql = "SELECT * FROM products WHERE name LIKE ?";  // Adjust based on your table structure

        try (Connection connection = myConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            // Use LIKE for partial matching, '%' allows matching any text before or after the query
            statement.setString(1, "%" + query + "%");

            // Execute the query
            ResultSet rs = statement.executeQuery();

            // Iterate through the results and create product objects
            while (rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt("id"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getDouble("price"));

                // Get the image data from the database (assuming it's stored as a BLOB or byte array)
                byte[] imageBytes = rs.getBytes("image");  // Adjust the column name based on your DB schema

                if (imageBytes != null && imageBytes.length > 0) {
                    // Convert byte array to Base64 string
                    String base64Image = convertImageToBase64(imageBytes);
                    product.setBase64Image(base64Image);  // Set Base64 image in product
                }

                // Add the product to the list
                products.add(product);
            }

        } catch (SQLException e) {
            e.printStackTrace();  // Handle exception as per your needs (e.g., log it)
        }
		return products;
        }
    public static boolean createOrder(Order order) {
        // Your JDBC logic to save the order in the database
        try (Connection conn = myConnection()) {
            String sql = "INSERT INTO orders (user_id, product_id, quantity, total_amount,order_date,status) VALUES (?, ?, ?, ?, ?,?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, order.getUserId());
                stmt.setInt(2, order.getProductId());
                stmt.setInt(3, order.getQuantity());
                stmt.setDouble(4, order.getTotalAmount());
                stmt.setTimestamp(5, new Timestamp(System.currentTimeMillis()));
                stmt.setString(6,"ordered");

                int rowsAffected = stmt.executeUpdate();
                return rowsAffected > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static List<Order> getOrdersByUserId(int id) {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT o.id, o.user_id, o.product_id, o.quantity, o.total_amount, o.status, p.name "
                   + "FROM orders o "
                   + "JOIN products p ON o.product_id = p.id " // Corrected join condition
                   + "WHERE o.user_id = ?"; // Corrected WHERE clause for user_id

        try (Connection conn = myConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Order order = new Order();
                order.setId(rs.getInt("id"));
                order.setUserId(rs.getInt("user_id"));
                order.setProductId(rs.getInt("product_id"));
                order.setQuantity(rs.getInt("quantity"));
                order.setTotalAmount(rs.getDouble("total_amount"));
                order.setStatus(rs.getString("status"));
                order.setProductName(rs.getString("name"));  // Set the product name
                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }
}
    

    	
	


package com.blogapp.controller;

import com.blogapp.model.Article;
import com.blogapp.model.User;
import com.blogapp.Repository.ArticleRepository;
import com.blogapp.Repository.UserRepository;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/articles")
public class ArticleController {

    private final ArticleRepository articleRepository;
    private final UserRepository userRepository;

    public ArticleController(ArticleRepository articleRepository, UserRepository userRepository) {
        this.articleRepository = articleRepository;
        this.userRepository = userRepository;
    }

    @GetMapping("/all")
    public List<Article> getAllArticles() {
        return articleRepository.findAll();
    }

    @PostMapping("/create")
    public String createArticle(@RequestBody Article article, Authentication authentication) {
        String username = authentication.getName();
        Optional<User> userOpt = userRepository.findByUsername(username);

        return userOpt.map(user -> {
            article.setAuthor(user);
            article.setPublishedAt(LocalDateTime.now());  // Ensure timestamp is set
            articleRepository.save(article);
            return "Article created successfully!";
        }).orElse("User not found!");
    }

    @GetMapping("/myarticles")
    public List<Article> getMyArticles(Authentication authentication) {
        String username = authentication.getName();
        Optional<User> userOpt = userRepository.findByUsername(username);

        return userOpt.map(user -> articleRepository.findByAuthorId(user.getId()))
                      .orElse(List.of());
    }
}
